from django.contrib import admin
from first.models import formmodel
# Register your models here.

class formadmin(admin.ModelAdmin):
    list_display=["name","age","password"]
admin.site.register(formmodel,formadmin)