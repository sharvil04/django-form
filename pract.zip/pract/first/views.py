from django.shortcuts import render,HttpResponse,redirect
from first.forms import login
from first.models import formmodel
# Create your views here.
def thanks(request):
    return render(request,"thanks.html")

def index(request):
    if request.method == "POST":
        form=login(request.POST)
        if form.is_valid():
            name=form.cleaned_data["name"]
            age=form.cleaned_data["age"]
            password=form.cleaned_data["password"]

            abc=formmodel.objects.create(name=name,age=age,password=password)
            abc.save()
            return redirect("/index/thanks/")
        else:
            return render(request,"index.html",{"form":form})
    else:
        form=login()
        return render(request,"index.html",{"form":form})