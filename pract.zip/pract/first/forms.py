from django import forms
class login(forms.Form):
    name=forms.CharField(max_length=520)
    age=forms.IntegerField()
    password=forms.CharField(widget=forms.PasswordInput)